import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart } from 'chart.js/auto';
import { NutritionSummary } from '../../../core/models/recipe.model';

@Component({
  selector: 'app-nutrition-chart',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="chart-container">
      <canvas #macroChart></canvas>
    </div>
  `,
  styles: [`
    .chart-container {
      position: relative;
      height: 200px;
      width: 100%;
      margin: 16px 0;
    }
  `]
})
export class NutritionChartComponent implements OnChanges {
  @Input() nutritionData!: NutritionSummary;
  private chart: any;
  
  constructor() {}
  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['nutritionData'] && this.nutritionData) {
      this.createOrUpdateChart();
    }
  }
  
  ngAfterViewInit(): void {
    if (this.nutritionData) {
      this.createOrUpdateChart();
    }
  }
  
  private createOrUpdateChart(): void {
    const canvas = document.querySelector('canvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Destroy previous chart if it exists
    if (this.chart) {
      this.chart.destroy();
    }
    
    const data = {
      labels: ['Protein', 'Fat', 'Carbs'],
      datasets: [{
        label: 'Macronutrients (%)',
        data: [
          this.nutritionData.proteinPercentage,
          this.nutritionData.fatPercentage,
          this.nutritionData.carbsPercentage
        ],
        backgroundColor: [
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 99, 132, 0.7)',
          'rgba(255, 206, 86, 0.7)'
        ],
        borderColor: [
          'rgba(54, 162, 235, 1)',
          'rgba(255, 99, 132, 1)',
          'rgba(255, 206, 86, 1)'
        ],
        borderWidth: 1
      }]
    };
    
    this.chart = new Chart(ctx, {
      type: 'doughnut',
      data: data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const label = context.label || '';
                const value = context.raw as number;
                return `${label}: ${value.toFixed(1)}%`;
              }
            }
          }
        }
      }
    });
  }
}