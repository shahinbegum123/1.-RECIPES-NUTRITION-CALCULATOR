import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="footer">
      <div class="container footer-container">
        <div class="footer-info">
          <p class="copyright">&copy; {{currentYear}} Recipes Nutrition Calculator</p>
          <p class="disclaimer">All nutritional data provided by USDA Food Database.</p>
        </div>
        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">Contact Us</a>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background-color: var(--primary-dark);
      color: white;
      padding: 24px 0;
      margin-top: 48px;
    }
    
    .footer-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .footer-info {
      font-size: 0.875rem;
    }
    
    .copyright {
      margin-bottom: 4px;
    }
    
    .disclaimer {
      color: rgba(255, 255, 255, 0.8);
    }
    
    .footer-links {
      display: flex;
      gap: 24px;
    }
    
    .footer-links a {
      color: white;
      text-decoration: none;
      font-size: 0.875rem;
      transition: opacity 0.2s ease;
    }
    
    .footer-links a:hover {
      opacity: 0.8;
      text-decoration: underline;
    }
    
    @media screen and (max-width: 768px) {
      .footer-container {
        flex-direction: column;
        gap: 16px;
        text-align: center;
      }
      
      .footer-links {
        flex-direction: column;
        gap: 8px;
      }
    }
  `]
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
}