import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="header">
      <div class="container header-container">
        <div class="logo">
          <a routerLink="/">
            <span class="logo-text">Recipes Nutrition</span>
          </a>
        </div>
        <nav class="nav">
          <ul class="nav-links">
            <li><a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Home</a></li>
            <li><a routerLink="/recipe-builder" routerLinkActive="active">Create Recipe</a></li>
            <li><a routerLink="/saved-recipes" routerLinkActive="active">Saved Recipes</a></li>
          </ul>
        </nav>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background-color: var(--primary);
      color: white;
      padding: 16px 0;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .header-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .logo a {
      text-decoration: none;
      color: white;
      display: flex;
      align-items: center;
    }
    
    .logo-text {
      font-family: 'Montserrat', sans-serif;
      font-size: 1.5rem;
      font-weight: 700;
    }
    
    .nav-links {
      display: flex;
      list-style: none;
      gap: 24px;
    }
    
    .nav-links a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      padding: 8px 0;
      position: relative;
      transition: color 0.2s ease;
    }
    
    .nav-links a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 0;
      height: 2px;
      background-color: white;
      transition: width 0.3s ease;
    }
    
    .nav-links a:hover::after,
    .nav-links a.active::after {
      width: 100%;
    }
    
    @media screen and (max-width: 768px) {
      .header-container {
        flex-direction: column;
        gap: 16px;
      }
      
      .nav-links {
        gap: 16px;
      }
    }
  `]
})
export class HeaderComponent {}