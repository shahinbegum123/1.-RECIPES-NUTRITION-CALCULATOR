export interface Recipe {
  id?: string;
  name: string;
  description?: string;
  servings: number;
  preparationTime?: number;
  cookingTime?: number;
  ingredients: Ingredient[];
  instructions?: string[];
  totalNutrition: NutritionSummary;
  tags?: string[];
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Ingredient {
  id?: string;
  name: string;
  quantity: number;
  unit: string;
  calories: number;
  nutrition: NutritionInfo;
  substitutes?: Ingredient[];
}

export interface NutritionInfo {
  calories: number;
  protein: number;
  fat: number;
  saturatedFat?: number;
  transFat?: number;
  cholesterol?: number;
  carbohydrates: number;
  fiber?: number;
  sugars?: number;
  sodium?: number;
  potassium?: number;
  calcium?: number;
  iron?: number;
  vitaminA?: number;
  vitaminC?: number;
  vitaminD?: number;
}

export interface NutritionSummary extends NutritionInfo {
  caloriesPerServing: number;
  proteinPercentage: number;
  fatPercentage: number;
  carbsPercentage: number;
}

export interface FoodItem {
  id: string;
  name: string;
  nutrition: NutritionInfo;
  servingSize: number;
  servingUnit: string;
}