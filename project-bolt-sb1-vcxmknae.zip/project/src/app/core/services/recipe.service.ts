import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Recipe, Ingredient, NutritionSummary } from '../models/recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  private recipes: Recipe[] = [];
  private currentRecipeSubject = new BehaviorSubject<Recipe | null>(null);
  
  currentRecipe$ = this.currentRecipeSubject.asObservable();
  
  constructor() {
    // Load saved recipes from localStorage
    this.loadRecipes();
  }
  
  private loadRecipes(): void {
    const savedRecipes = localStorage.getItem('recipes');
    if (savedRecipes) {
      this.recipes = JSON.parse(savedRecipes);
    }
  }
  
  private saveRecipes(): void {
    localStorage.setItem('recipes', JSON.stringify(this.recipes));
  }
  
  getAllRecipes(): Observable<Recipe[]> {
    return of([...this.recipes]);
  }
  
  getRecipeById(id: string): Observable<Recipe | undefined> {
    const recipe = this.recipes.find(r => r.id === id);
    return of(recipe);
  }
  
  createRecipe(recipe: Omit<Recipe, 'id' | 'totalNutrition'>): Observable<Recipe> {
    const newRecipe: Recipe = {
      ...recipe,
      id: this.generateId(),
      totalNutrition: this.calculateTotalNutrition(recipe.ingredients, recipe.servings),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.recipes.push(newRecipe);
    this.saveRecipes();
    this.setCurrentRecipe(newRecipe);
    
    return of(newRecipe);
  }
  
  updateRecipe(recipe: Recipe): Observable<Recipe> {
    const index = this.recipes.findIndex(r => r.id === recipe.id);
    
    if (index !== -1) {
      // Recalculate nutrition if needed
      if (!this.compareIngredients(this.recipes[index].ingredients, recipe.ingredients) ||
          this.recipes[index].servings !== recipe.servings) {
        recipe.totalNutrition = this.calculateTotalNutrition(recipe.ingredients, recipe.servings);
      }
      
      recipe.updatedAt = new Date();
      this.recipes[index] = recipe;
      this.saveRecipes();
      this.setCurrentRecipe(recipe);
      
      return of(recipe);
    }
    
    return of(recipe);
  }
  
  deleteRecipe(id: string): Observable<boolean> {
    const index = this.recipes.findIndex(r => r.id === id);
    
    if (index !== -1) {
      this.recipes.splice(index, 1);
      this.saveRecipes();
      
      if (this.currentRecipeSubject.value?.id === id) {
        this.setCurrentRecipe(null);
      }
      
      return of(true);
    }
    
    return of(false);
  }
  
  setCurrentRecipe(recipe: Recipe | null): void {
    this.currentRecipeSubject.next(recipe);
  }
  
  private calculateTotalNutrition(ingredients: Ingredient[], servings: number): NutritionSummary {
    // Initialize with zeros
    const totalNutrition: NutritionSummary = {
      calories: 0,
      protein: 0,
      fat: 0,
      saturatedFat: 0,
      transFat: 0,
      cholesterol: 0,
      carbohydrates: 0,
      fiber: 0,
      sugars: 0,
      sodium: 0,
      potassium: 0,
      calcium: 0,
      iron: 0,
      vitaminA: 0,
      vitaminC: 0,
      vitaminD: 0,
      caloriesPerServing: 0,
      proteinPercentage: 0,
      fatPercentage: 0,
      carbsPercentage: 0
    };
    
    // Sum all nutrition values from ingredients
    for (const ingredient of ingredients) {
      totalNutrition.calories += ingredient.nutrition.calories;
      totalNutrition.protein += ingredient.nutrition.protein;
      totalNutrition.fat += ingredient.nutrition.fat;
      totalNutrition.carbohydrates += ingredient.nutrition.carbohydrates;
      
      // Add optional nutrients if they exist
      if (ingredient.nutrition.saturatedFat) totalNutrition.saturatedFat! += ingredient.nutrition.saturatedFat;
      if (ingredient.nutrition.transFat) totalNutrition.transFat! += ingredient.nutrition.transFat;
      if (ingredient.nutrition.cholesterol) totalNutrition.cholesterol! += ingredient.nutrition.cholesterol;
      if (ingredient.nutrition.fiber) totalNutrition.fiber! += ingredient.nutrition.fiber;
      if (ingredient.nutrition.sugars) totalNutrition.sugars! += ingredient.nutrition.sugars;
      if (ingredient.nutrition.sodium) totalNutrition.sodium! += ingredient.nutrition.sodium;
      if (ingredient.nutrition.potassium) totalNutrition.potassium! += ingredient.nutrition.potassium;
      if (ingredient.nutrition.calcium) totalNutrition.calcium! += ingredient.nutrition.calcium;
      if (ingredient.nutrition.iron) totalNutrition.iron! += ingredient.nutrition.iron;
      if (ingredient.nutrition.vitaminA) totalNutrition.vitaminA! += ingredient.nutrition.vitaminA;
      if (ingredient.nutrition.vitaminC) totalNutrition.vitaminC! += ingredient.nutrition.vitaminC;
      if (ingredient.nutrition.vitaminD) totalNutrition.vitaminD! += ingredient.nutrition.vitaminD;
    }
    
    // Calculate per serving values
    totalNutrition.caloriesPerServing = totalNutrition.calories / servings;
    
    // Calculate macronutrient percentages
    const totalMacros = totalNutrition.protein * 4 + totalNutrition.fat * 9 + totalNutrition.carbohydrates * 4;
    
    if (totalMacros > 0) {
      totalNutrition.proteinPercentage = (totalNutrition.protein * 4 / totalMacros) * 100;
      totalNutrition.fatPercentage = (totalNutrition.fat * 9 / totalMacros) * 100;
      totalNutrition.carbsPercentage = (totalNutrition.carbohydrates * 4 / totalMacros) * 100;
    }
    
    return totalNutrition;
  }
  
  private compareIngredients(a: Ingredient[], b: Ingredient[]): boolean {
    if (a.length !== b.length) return false;
    
    for (let i = 0; i < a.length; i++) {
      if (a[i].name !== b[i].name || 
          a[i].quantity !== b[i].quantity || 
          a[i].unit !== b[i].unit) {
        return false;
      }
    }
    
    return true;
  }
  
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
  }
}