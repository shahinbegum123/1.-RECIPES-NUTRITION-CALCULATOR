import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { FoodItem, NutritionInfo } from '../models/recipe.model';

@Injectable({
  providedIn: 'root'
})
export class NutritionApiService {
  private readonly apiUrl = 'https://api.nal.usda.gov/fdc/v1';
  // In a real app, this would be in an environment file
  private readonly apiKey = 'DEMO_KEY'; 

  constructor(private http: HttpClient) {}

  searchFoodItems(query: string): Observable<FoodItem[]> {
    if (!query.trim()) {
      return of([]);
    }
    
    const params = new HttpParams()
      .set('api_key', this.apiKey)
      .set('query', query)
      .set('dataType', 'Foundation,SR Legacy')
      .set('pageSize', '10');
    
    return this.http.get<any>(`${this.apiUrl}/foods/search`, { params })
      .pipe(
        map(response => this.mapResponseToFoodItems(response)),
        catchError(error => {
          console.error('Error searching for food:', error);
          // Return demo data for now
          return of(this.getDemoFoodItems(query));
        })
      );
  }
  
  getFoodDetails(fdcId: string): Observable<NutritionInfo> {
    const params = new HttpParams()
      .set('api_key', this.apiKey);
    
    return this.http.get<any>(`${this.apiUrl}/food/${fdcId}`, { params })
      .pipe(
        map(response => this.mapResponseToNutritionInfo(response)),
        catchError(error => {
          console.error('Error getting food details:', error);
          return of(this.getDefaultNutritionInfo());
        })
      );
  }
  
  parseIngredientText(ingredientText: string): Observable<any> {
    // This would connect to a parsing service in a real app
    // For now, we'll implement a basic parsing function
    return of(this.parseIngredient(ingredientText));
  }
  
  private parseIngredient(text: string): any {
    // Basic parsing algorithm - in a real app, this would be much more sophisticated
    const regex = /^([\d.\/]+)?\s*([a-zA-Z]+)?\s*(?:of\s*)?(.*)/;
    const match = text.match(regex);
    
    if (!match) {
      return {
        quantity: 1,
        unit: 'serving',
        name: text.trim()
      };
    }
    
    const [, quantityStr, unit, name] = match;
    
    let quantity = 1;
    if (quantityStr) {
      if (quantityStr.includes('/')) {
        const [numerator, denominator] = quantityStr.split('/');
        quantity = Number(numerator) / Number(denominator);
      } else {
        quantity = Number(quantityStr);
      }
    }
    
    return {
      quantity,
      unit: unit || 'serving',
      name: name.trim()
    };
  }
  
  private mapResponseToFoodItems(response: any): FoodItem[] {
    if (!response || !response.foods) {
      return [];
    }
    
    return response.foods.map((food: any) => {
      return {
        id: food.fdcId,
        name: food.description,
        nutrition: this.extractNutritionFromFood(food),
        servingSize: food.servingSize || 100,
        servingUnit: food.servingSizeUnit || 'g'
      };
    });
  }
  
  private extractNutritionFromFood(food: any): NutritionInfo {
    // This would extract all nutrients in a real app
    // Here's a simplified version
    return {
      calories: this.getNutrientValue(food, 'Energy'),
      protein: this.getNutrientValue(food, 'Protein'),
      fat: this.getNutrientValue(food, 'Total lipid (fat)'),
      carbohydrates: this.getNutrientValue(food, 'Carbohydrate, by difference'),
      fiber: this.getNutrientValue(food, 'Fiber, total dietary'),
      sugars: this.getNutrientValue(food, 'Sugars, total'),
      sodium: this.getNutrientValue(food, 'Sodium, Na')
    };
  }
  
  private getNutrientValue(food: any, name: string): number {
    if (!food.foodNutrients) return 0;
    
    const nutrient = food.foodNutrients.find((n: any) => 
      n.nutrientName === name || (n.nutrient && n.nutrient.name === name)
    );
    
    return nutrient ? nutrient.value : 0;
  }
  
  private mapResponseToNutritionInfo(response: any): NutritionInfo {
    // Map detailed nutrition information
    return this.extractNutritionFromFood(response);
  }
  
  private getDefaultNutritionInfo(): NutritionInfo {
    return {
      calories: 0,
      protein: 0,
      fat: 0,
      carbohydrates: 0,
      fiber: 0,
      sugars: 0,
      sodium: 0
    };
  }
  
  // Demo data for development - would be removed in production
  private getDemoFoodItems(query: string): FoodItem[] {
    const demoItems: FoodItem[] = [
      {
        id: '1',
        name: 'Apple',
        nutrition: {
          calories: 52,
          protein: 0.3,
          fat: 0.2,
          carbohydrates: 14,
          fiber: 2.4,
          sugars: 10.3,
          sodium: 1
        },
        servingSize: 100,
        servingUnit: 'g'
      },
      {
        id: '2',
        name: 'Chicken Breast',
        nutrition: {
          calories: 165,
          protein: 31,
          fat: 3.6,
          carbohydrates: 0,
          fiber: 0,
          sugars: 0,
          sodium: 74
        },
        servingSize: 100,
        servingUnit: 'g'
      },
      {
        id: '3',
        name: 'Brown Rice',
        nutrition: {
          calories: 112,
          protein: 2.6,
          fat: 0.9,
          carbohydrates: 23.5,
          fiber: 1.8,
          sugars: 0.4,
          sodium: 5
        },
        servingSize: 100,
        servingUnit: 'g'
      }
    ];
    
    return demoItems.filter(item => 
      item.name.toLowerCase().includes(query.toLowerCase())
    );
  }
}