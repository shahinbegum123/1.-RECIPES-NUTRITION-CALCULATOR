import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { RecipeService } from '../../core/services/recipe.service';
import { Recipe } from '../../core/models/recipe.model';
import { NutritionChartComponent } from '../../shared/components/nutrition-chart/nutrition-chart.component';

@Component({
  selector: 'app-nutrition-results',
  standalone: true,
  imports: [CommonModule, RouterLink, NutritionChartComponent],
  template: `
    <div class="nutrition-results fade-in" *ngIf="recipe">
      <div class="results-header">
        <h1>{{recipe.name}}</h1>
        <p *ngIf="recipe.description" class="recipe-description">{{recipe.description}}</p>
        
        <div class="recipe-meta">
          <div class="meta-item">
            <div class="meta-label">Servings</div>
            <div class="meta-value">{{recipe.servings}}</div>
          </div>
          
          <div class="meta-item" *ngIf="recipe.cookingTime">
            <div class="meta-label">Cooking Time</div>
            <div class="meta-value">{{recipe.cookingTime}} min</div>
          </div>
          
          <div class="meta-item">
            <div class="meta-label">Total Calories</div>
            <div class="meta-value">{{recipe.totalNutrition.calories | number:'1.0-0'}}</div>
          </div>
          
          <div class="meta-item">
            <div class="meta-label">Calories/Serving</div>
            <div class="meta-value">{{recipe.totalNutrition.caloriesPerServing | number:'1.0-0'}}</div>
          </div>
        </div>
      </div>
      
      <div class="results-content">
        <div class="card nutrition-summary">
          <h2>Nutrition Summary</h2>
          
          <app-nutrition-chart [nutritionData]="recipe.totalNutrition"></app-nutrition-chart>
          
          <div class="macros">
            <div class="macro-item">
              <div class="macro-label">Protein</div>
              <div class="macro-value">{{recipe.totalNutrition.protein | number:'1.1-1'}}g</div>
              <div class="macro-percentage">{{recipe.totalNutrition.proteinPercentage | number:'1.0-0'}}%</div>
            </div>
            
            <div class="macro-item">
              <div class="macro-label">Fat</div>
              <div class="macro-value">{{recipe.totalNutrition.fat | number:'1.1-1'}}g</div>
              <div class="macro-percentage">{{recipe.totalNutrition.fatPercentage | number:'1.0-0'}}%</div>
            </div>
            
            <div class="macro-item">
              <div class="macro-label">Carbs</div>
              <div class="macro-value">{{recipe.totalNutrition.carbohydrates | number:'1.1-1'}}g</div>
              <div class="macro-percentage">{{recipe.totalNutrition.carbsPercentage | number:'1.0-0'}}%</div>
            </div>
          </div>
          
          <div class="nutrition-details">
            <h3>Detailed Nutrition Facts</h3>
            
            <div class="nutrition-table">
              <div class="nutrition-row header">
                <div class="nutrient">Nutrient</div>
                <div class="amount">Total Amount</div>
                <div class="per-serving">Per Serving</div>
              </div>
              
              <div class="nutrition-row">
                <div class="nutrient">Calories</div>
                <div class="amount">{{recipe.totalNutrition.calories | number:'1.0-0'}}</div>
                <div class="per-serving">{{recipe.totalNutrition.caloriesPerServing | number:'1.0-0'}}</div>
              </div>
              
              <div class="nutrition-row">
                <div class="nutrient">Protein</div>
                <div class="amount">{{recipe.totalNutrition.protein | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.protein / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row">
                <div class="nutrient">Fat</div>
                <div class="amount">{{recipe.totalNutrition.fat | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.fat / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row" *ngIf="recipe.totalNutrition.saturatedFat">
                <div class="nutrient sub-nutrient">- Saturated Fat</div>
                <div class="amount">{{recipe.totalNutrition.saturatedFat | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.saturatedFat / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row">
                <div class="nutrient">Carbohydrates</div>
                <div class="amount">{{recipe.totalNutrition.carbohydrates | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.carbohydrates / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row" *ngIf="recipe.totalNutrition.fiber">
                <div class="nutrient sub-nutrient">- Fiber</div>
                <div class="amount">{{recipe.totalNutrition.fiber | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.fiber / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row" *ngIf="recipe.totalNutrition.sugars">
                <div class="nutrient sub-nutrient">- Sugars</div>
                <div class="amount">{{recipe.totalNutrition.sugars | number:'1.1-1'}}g</div>
                <div class="per-serving">{{recipe.totalNutrition.sugars / recipe.servings | number:'1.1-1'}}g</div>
              </div>
              
              <div class="nutrition-row" *ngIf="recipe.totalNutrition.sodium">
                <div class="nutrient">Sodium</div>
                <div class="amount">{{recipe.totalNutrition.sodium | number:'1.0-0'}}mg</div>
                <div class="per-serving">{{recipe.totalNutrition.sodium / recipe.servings | number:'1.0-0'}}mg</div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="card ingredients-list">
          <h2>Ingredients</h2>
          <ul>
            <li *ngFor="let ingredient of recipe.ingredients">
              <span class="ingredient-quantity">{{ingredient.quantity}}</span>
              <span class="ingredient-unit">{{ingredient.unit}}</span>
              <span class="ingredient-name">{{ingredient.name}}</span>
              <span class="ingredient-calories">({{ingredient.nutrition.calories | number:'1.0-0'}} cal)</span>
            </li>
          </ul>
          
          <div *ngIf="recipe.instructions && recipe.instructions.length > 0" class="instructions">
            <h3>Instructions</h3>
            <ol>
              <li *ngFor="let instruction of recipe.instructions">{{instruction}}</li>
            </ol>
          </div>
        </div>
      </div>
      
      <div class="actions">
        <button class="btn btn-secondary" routerLink="/recipe-builder">Create New Recipe</button>
        <button class="btn btn-primary" routerLink="/saved-recipes">View All Recipes</button>
      </div>
    </div>
    
    <div class="loading" *ngIf="!recipe">
      <p>Loading recipe information...</p>
    </div>
  `,
  styles: [`
    .nutrition-results {
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .results-header {
      margin-bottom: 32px;
    }
    
    .recipe-description {
      color: var(--text-secondary);
      font-size: 1.1rem;
      margin-bottom: 24px;
    }
    
    .recipe-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 24px;
      margin-top: 24px;
    }
    
    .meta-item {
      background-color: var(--surface);
      padding: 12px 16px;
      border-radius: 8px;
      min-width: 120px;
      text-align: center;
    }
    
    .meta-label {
      font-size: 0.875rem;
      color: var(--text-secondary);
      margin-bottom: 4px;
    }
    
    .meta-value {
      font-size: 1.25rem;
      font-weight: 500;
      color: var(--text-primary);
    }
    
    .results-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      margin-bottom: 32px;
    }
    
    .nutrition-summary {
      grid-column: 1;
    }
    
    .ingredients-list {
      grid-column: 2;
    }
    
    .macros {
      display: flex;
      justify-content: space-between;
      margin: 24px 0;
      gap: 16px;
    }
    
    .macro-item {
      background-color: var(--surface);
      padding: 16px;
      border-radius: 8px;
      text-align: center;
      flex-grow: 1;
    }
    
    .macro-label {
      font-weight: 500;
      margin-bottom: 8px;
    }
    
    .macro-value {
      font-size: 1.5rem;
      font-weight: 600;
      margin-bottom: 4px;
    }
    
    .macro-percentage {
      color: var(--text-secondary);
    }
    
    .nutrition-details {
      margin-top: 32px;
    }
    
    .nutrition-table {
      margin-top: 16px;
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
    }
    
    .nutrition-row {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr;
      padding: 8px 16px;
    }
    
    .nutrition-row:nth-child(odd) {
      background-color: var(--surface);
    }
    
    .nutrition-row.header {
      background-color: var(--primary-light);
      font-weight: 500;
      padding: 12px 16px;
    }
    
    .sub-nutrient {
      padding-left: 16px;
      color: var(--text-secondary);
    }
    
    .ingredients-list ul {
      margin-top: 16px;
      list-style: none;
    }
    
    .ingredients-list li {
      margin-bottom: 12px;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }
    
    .ingredient-quantity {
      font-weight: 500;
    }
    
    .ingredient-unit {
      color: var(--text-secondary);
    }
    
    .ingredient-calories {
      color: var(--text-secondary);
      font-size: 0.9rem;
      margin-left: 4px;
    }
    
    .instructions {
      margin-top: 32px;
    }
    
    .instructions ol {
      margin-top: 16px;
      padding-left: 24px;
    }
    
    .instructions li {
      margin-bottom: 16px;
      line-height: 1.6;
    }
    
    .actions {
      display: flex;
      justify-content: center;
      gap: 16px;
      margin-top: 32px;
    }
    
    .loading {
      text-align: center;
      padding: 64px 0;
      color: var(--text-secondary);
    }
    
    @media (max-width: 768px) {
      .results-content {
        grid-template-columns: 1fr;
      }
      
      .nutrition-summary, .ingredients-list {
        grid-column: 1;
      }
      
      .meta-item {
        flex-basis: calc(50% - 12px);
      }
      
      .actions {
        flex-direction: column;
      }
    }
  `]
})
export class NutritionResultsComponent implements OnInit {
  recipe: Recipe | undefined;
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private recipeService: RecipeService
  ) {}
  
  ngOnInit(): void {
    this.loadRecipe();
  }
  
  private loadRecipe(): void {
    const recipeId = this.route.snapshot.paramMap.get('id');
    if (!recipeId) {
      this.router.navigate(['/']);
      return;
    }
    
    this.recipeService.getRecipeById(recipeId).subscribe(recipe => {
      if (recipe) {
        this.recipe = recipe;
      } else {
        this.router.navigate(['/']);
      }
    });
  }
}