import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="home-container fade-in">
      <section class="hero">
        <div class="hero-content">
          <h1>Calculate Your Recipe's Nutrition</h1>
          <p class="lead">Analyze any recipe's nutritional content in seconds. Make informed decisions about your meals and eating habits.</p>
          <div class="cta-buttons">
            <a routerLink="/recipe-builder" class="btn btn-primary">Create Recipe</a>
            <a routerLink="/saved-recipes" class="btn btn-secondary">View Saved Recipes</a>
          </div>
        </div>
      </section>
      
      <section class="features">
        <h2 class="text-center mb-32">Make Better Food Choices</h2>
        <div class="feature-grid">
          <div class="feature-card card">
            <div class="feature-icon">📊</div>
            <h3>Detailed Analysis</h3>
            <p>Get complete nutritional breakdown including calories, macronutrients, vitamins and minerals.</p>
          </div>
          
          <div class="feature-card card">
            <div class="feature-icon">📝</div>
            <h3>Simple Recipe Input</h3>
            <p>Add ingredients in plain language - our system will analyze and categorize them automatically.</p>
          </div>
          
          <div class="feature-card card">
            <div class="feature-icon">🔄</div>
            <h3>Ingredient Substitutions</h3>
            <p>Discover healthier alternatives to ingredients to improve your recipe's nutritional profile.</p>
          </div>
          
          <div class="feature-card card">
            <div class="feature-icon">💾</div>
            <h3>Save Your Recipes</h3>
            <p>Build a personal collection of analyzed recipes for quick future reference.</p>
          </div>
        </div>
      </section>
      
      <section class="how-it-works">
        <h2 class="text-center mb-32">How It Works</h2>
        <div class="steps">
          <div class="step">
            <div class="step-number">1</div>
            <div class="step-content">
              <h3>Enter Your Recipe</h3>
              <p>Add your recipe name, ingredients, and the number of servings.</p>
            </div>
          </div>
          
          <div class="step">
            <div class="step-number">2</div>
            <div class="step-content">
              <h3>Review Ingredients</h3>
              <p>Our system will parse your ingredients and match them to our database. You can adjust quantities if needed.</p>
            </div>
          </div>
          
          <div class="step">
            <div class="step-number">3</div>
            <div class="step-content">
              <h3>Get Nutrition Data</h3>
              <p>See detailed nutritional information for your whole recipe and per serving.</p>
            </div>
          </div>
          
          <div class="step">
            <div class="step-number">4</div>
            <div class="step-content">
              <h3>Save and Share</h3>
              <p>Save your recipe for future reference or share nutrition facts with others.</p>
            </div>
          </div>
        </div>
      </section>
      
      <section class="cta-section">
        <div class="cta-content">
          <h2>Ready to analyze your first recipe?</h2>
          <p>Start now and get accurate nutrition information in seconds.</p>
          <a routerLink="/recipe-builder" class="btn btn-primary">Get Started</a>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .home-container {
      max-width: 100%;
    }
    
    .hero {
      background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
                  url('https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2');
      background-size: cover;
      background-position: center;
      color: white;
      padding: 80px 0;
      text-align: center;
      margin-bottom: 48px;
      border-radius: 8px;
    }
    
    .hero-content {
      max-width: 800px;
      margin: 0 auto;
      padding: 0 16px;
    }
    
    h1 {
      font-size: 3rem;
      margin-bottom: 24px;
      color: white;
    }
    
    .lead {
      font-size: 1.25rem;
      margin-bottom: 32px;
      line-height: 1.6;
    }
    
    .cta-buttons {
      display: flex;
      gap: 16px;
      justify-content: center;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
      padding: 12px 24px;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.2s;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
    }
    
    .btn-secondary {
      background-color: var(--secondary);
      color: white;
      padding: 12px 24px;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.2s;
    }
    
    .btn-secondary:hover {
      background-color: var(--secondary-dark);
    }
    
    .features {
      margin-bottom: 64px;
    }
    
    .feature-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 24px;
    }
    
    .feature-card {
      padding: 24px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .feature-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }
    
    .feature-icon {
      font-size: 3rem;
      margin-bottom: 16px;
    }
    
    .how-it-works {
      margin-bottom: 64px;
    }
    
    .steps {
      max-width: 800px;
      margin: 0 auto;
    }
    
    .step {
      display: flex;
      margin-bottom: 32px;
      position: relative;
    }
    
    .step:not(:last-child)::after {
      content: '';
      position: absolute;
      left: 20px;
      top: 40px;
      bottom: -20px;
      width: 2px;
      background-color: var(--primary-light);
    }
    
    .step-number {
      background-color: var(--primary);
      color: white;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      margin-right: 16px;
      flex-shrink: 0;
      z-index: 1;
    }
    
    .step-content {
      flex-grow: 1;
    }
    
    .cta-section {
      background-color: var(--primary-light);
      padding: 64px 0;
      text-align: center;
      border-radius: 8px;
    }
    
    .cta-content {
      max-width: 600px;
      margin: 0 auto;
    }
    
    .cta-content h2 {
      margin-bottom: 16px;
      color: var(--text-primary);
    }
    
    .cta-content p {
      margin-bottom: 24px;
      color: var(--text-primary);
    }
    
    @media (max-width: 768px) {
      h1 {
        font-size: 2.25rem;
      }
      
      .cta-buttons {
        flex-direction: column;
        gap: 12px;
      }
      
      .feature-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class HomeComponent {}