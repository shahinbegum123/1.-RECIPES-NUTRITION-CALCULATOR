import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RecipeService } from '../../core/services/recipe.service';
import { NutritionApiService } from '../../core/services/nutrition-api.service';
import { Recipe, Ingredient, FoodItem } from '../../core/models/recipe.model';

@Component({
  selector: 'app-recipe-builder',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  template: `
    <div class="recipe-builder fade-in">
      <h1>Create Recipe</h1>
      
      <form [formGroup]="recipeForm" (ngSubmit)="onSubmit()">
        <div class="form-section card">
          <h2>Recipe Details</h2>
          
          <div class="form-group">
            <label for="recipeName">Recipe Name</label>
            <input type="text" id="recipeName" class="form-control" formControlName="name" placeholder="E.g., Chicken Stir Fry">
            <div *ngIf="recipeForm.get('name')?.invalid && recipeForm.get('name')?.touched" class="error-message">
              Recipe name is required
            </div>
          </div>
          
          <div class="form-group">
            <label for="description">Description (Optional)</label>
            <textarea id="description" class="form-control" formControlName="description" placeholder="Briefly describe your recipe..."></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group half-width">
              <label for="servings">Servings</label>
              <input type="number" id="servings" class="form-control" formControlName="servings" min="1">
              <div *ngIf="recipeForm.get('servings')?.invalid && recipeForm.get('servings')?.touched" class="error-message">
                Servings must be at least 1
              </div>
            </div>
            
            <div class="form-group half-width">
              <label for="cookTime">Cooking Time (minutes)</label>
              <input type="number" id="cookTime" class="form-control" formControlName="cookingTime" min="0">
            </div>
          </div>
        </div>
        
        <div class="form-section card">
          <h2>Ingredients</h2>
          <p class="hint-text">Add each ingredient with its quantity and unit (e.g., 2 cups flour, 1/2 tsp salt)</p>
          
          <div formArrayName="ingredients">
            <div *ngFor="let ingredient of ingredientsFormArray.controls; let i = index" class="ingredient-row" [formGroupName]="i">
              <div class="ingredient-inputs">
                <div class="form-group ingredient-text">
                  <input type="text" class="form-control" formControlName="text" placeholder="Enter ingredient" 
                    (blur)="parseIngredient(i)">
                  <div *ngIf="ingredient.get('text')?.invalid && ingredient.get('text')?.touched" class="error-message">
                    Ingredient is required
                  </div>
                </div>
                
                <div *ngIf="ingredient.get('parsed')?.value" class="parsed-ingredient">
                  <span class="quantity">{{ingredient.get('quantity')?.value}}</span>
                  <span class="unit">{{ingredient.get('unit')?.value}}</span>
                  <span class="name">{{ingredient.get('name')?.value}}</span>
                </div>
              </div>
              
              <button type="button" class="btn-remove" (click)="removeIngredient(i)" *ngIf="ingredientsFormArray.controls.length > 1">
                ✕
              </button>
            </div>
          </div>
          
          <button type="button" class="btn btn-secondary btn-add" (click)="addIngredient()">
            + Add Ingredient
          </button>
        </div>
        
        <div class="form-section card">
          <h2>Instructions (Optional)</h2>
          
          <div formArrayName="instructions">
            <div *ngFor="let instruction of instructionsFormArray.controls; let i = index" class="instruction-row">
              <div class="form-group instruction-text">
                <div class="instruction-number">{{i + 1}}</div>
                <textarea class="form-control" [formControlName]="i" placeholder="Describe this step..."></textarea>
              </div>
              
              <button type="button" class="btn-remove" (click)="removeInstruction(i)" *ngIf="instructionsFormArray.controls.length > 1">
                ✕
              </button>
            </div>
          </div>
          
          <button type="button" class="btn btn-secondary btn-add" (click)="addInstruction()">
            + Add Step
          </button>
        </div>
        
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" (click)="cancel()">Cancel</button>
          <button type="submit" class="btn btn-primary" [disabled]="recipeForm.invalid || isSubmitting">
            {{ isSubmitting ? 'Calculating...' : 'Calculate Nutrition' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .recipe-builder {
      max-width: 800px;
      margin: 0 auto;
    }
    
    .form-section {
      margin-bottom: 32px;
    }
    
    .form-row {
      display: flex;
      gap: 16px;
    }
    
    .half-width {
      width: 50%;
    }
    
    .hint-text {
      margin-bottom: 16px;
      color: var(--text-secondary);
      font-style: italic;
    }
    
    .ingredient-row {
      display: flex;
      gap: 8px;
      margin-bottom: 12px;
      align-items: flex-start;
    }
    
    .ingredient-inputs {
      flex-grow: 1;
    }
    
    .ingredient-text {
      margin-bottom: 4px;
    }
    
    .parsed-ingredient {
      background-color: var(--surface);
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 0.9rem;
      animation: fadeIn 0.3s ease;
    }
    
    .quantity {
      font-weight: 500;
      margin-right: 4px;
    }
    
    .unit {
      margin-right: 4px;
      color: var(--text-secondary);
    }
    
    .name {
      font-weight: 500;
    }
    
    .instruction-row {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
      align-items: flex-start;
    }
    
    .instruction-text {
      flex-grow: 1;
      display: flex;
      gap: 12px;
    }
    
    .instruction-number {
      background-color: var(--primary);
      color: white;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.875rem;
      margin-top: 8px;
    }
    
    .btn-remove {
      background-color: transparent;
      border: none;
      color: var(--error);
      cursor: pointer;
      font-size: 1rem;
      padding: 4px 8px;
      border-radius: 4px;
      transition: background-color 0.2s;
    }
    
    .btn-remove:hover {
      background-color: rgba(244, 67, 54, 0.1);
    }
    
    .btn-add {
      margin-top: 8px;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 16px;
      margin-top: 32px;
    }
    
    .error-message {
      color: var(--error);
      font-size: 0.875rem;
      margin-top: 4px;
    }
    
    textarea {
      min-height: 80px;
      resize: vertical;
    }
    
    @media (max-width: 768px) {
      .form-row {
        flex-direction: column;
        gap: 8px;
      }
      
      .half-width {
        width: 100%;
      }
    }
  `]
})
export class RecipeBuilderComponent implements OnInit {
  recipeForm!: FormGroup;
  isSubmitting = false;
  
  constructor(
    private fb: FormBuilder,
    private recipeService: RecipeService,
    private nutritionService: NutritionApiService,
    private router: Router
  ) {}
  
  ngOnInit(): void {
    this.initForm();
  }
  
  get ingredientsFormArray(): FormArray {
    return this.recipeForm.get('ingredients') as FormArray;
  }
  
  get instructionsFormArray(): FormArray {
    return this.recipeForm.get('instructions') as FormArray;
  }
  
  initForm(): void {
    this.recipeForm = this.fb.group({
      name: ['', [Validators.required]],
      description: [''],
      servings: [4, [Validators.required, Validators.min(1)]],
      cookingTime: [0],
      ingredients: this.fb.array([this.createIngredientFormGroup()]),
      instructions: this.fb.array([this.fb.control('')])
    });
  }
  
  createIngredientFormGroup(): FormGroup {
    return this.fb.group({
      text: ['', [Validators.required]],
      name: [''],
      quantity: [0],
      unit: [''],
      calories: [0],
      nutrition: this.fb.group({
        calories: [0],
        protein: [0],
        fat: [0],
        carbohydrates: [0]
      }),
      parsed: [false]
    });
  }
  
  addIngredient(): void {
    this.ingredientsFormArray.push(this.createIngredientFormGroup());
  }
  
  removeIngredient(index: number): void {
    this.ingredientsFormArray.removeAt(index);
  }
  
  addInstruction(): void {
    this.instructionsFormArray.push(this.fb.control(''));
  }
  
  removeInstruction(index: number): void {
    this.instructionsFormArray.removeAt(index);
  }
  
  parseIngredient(index: number): void {
    const ingredientGroup = this.ingredientsFormArray.at(index) as FormGroup;
    const ingredientText = ingredientGroup.get('text')?.value;
    
    if (!ingredientText) return;
    
    this.nutritionService.parseIngredientText(ingredientText).subscribe(parsed => {
      if (parsed) {
        ingredientGroup.patchValue({
          name: parsed.name,
          quantity: parsed.quantity,
          unit: parsed.unit,
          parsed: true
        });
        
        // For demo purposes, fetch nutrition data for the parsed ingredient
        // In a real app, we would search the database for a match
        this.fetchNutritionData(parsed.name, index);
      }
    });
  }
  
  fetchNutritionData(name: string, index: number): void {
    this.nutritionService.searchFoodItems(name).subscribe(items => {
      if (items && items.length > 0) {
        const ingredientGroup = this.ingredientsFormArray.at(index) as FormGroup;
        const bestMatch = items[0];
        
        // Apply nutrition data to the ingredient
        ingredientGroup.patchValue({
          calories: bestMatch.nutrition.calories,
          nutrition: bestMatch.nutrition
        });
      }
    });
  }
  
  onSubmit(): void {
    if (this.recipeForm.invalid) {
      this.markFormGroupTouched(this.recipeForm);
      return;
    }
    
    this.isSubmitting = true;
    
    // Transform form data to Recipe object
    const formValue = this.recipeForm.value;
    
    const ingredients: Ingredient[] = formValue.ingredients.map((ing: any) => {
      return {
        name: ing.name || ing.text,
        quantity: ing.quantity || 1,
        unit: ing.unit || 'serving',
        calories: ing.calories || 0,
        nutrition: ing.nutrition || {
          calories: 0,
          protein: 0,
          fat: 0,
          carbohydrates: 0
        }
      };
    });
    
    const recipe: Omit<Recipe, 'id' | 'totalNutrition'> = {
      name: formValue.name,
      description: formValue.description,
      servings: formValue.servings,
      cookingTime: formValue.cookingTime,
      ingredients: ingredients,
      instructions: formValue.instructions.filter((i: string) => i.trim())
    };
    
    // Save recipe and navigate to results
    this.recipeService.createRecipe(recipe).subscribe(newRecipe => {
      this.isSubmitting = false;
      this.router.navigate(['/nutrition-results', newRecipe.id]);
    });
  }
  
  cancel(): void {
    this.router.navigate(['/']);
  }
  
  // Helper to mark all controls as touched for validation messages
  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      } else if (control instanceof FormArray) {
        control.controls.forEach(c => {
          if (c instanceof FormGroup) {
            this.markFormGroupTouched(c);
          } else {
            c.markAsTouched();
          }
        });
      }
    });
  }
}