import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RecipeService } from '../../core/services/recipe.service';
import { Recipe } from '../../core/models/recipe.model';

@Component({
  selector: 'app-saved-recipes',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="saved-recipes fade-in">
      <div class="header">
        <h1>Saved Recipes</h1>
        <a routerLink="/recipe-builder" class="btn btn-primary">Create New Recipe</a>
      </div>
      
      <div *ngIf="recipes.length === 0" class="empty-state card">
        <div class="empty-icon">📝</div>
        <h2>No Recipes Yet</h2>
        <p>You haven't created any recipes yet. Get started by adding your first recipe!</p>
        <a routerLink="/recipe-builder" class="btn btn-primary">Create First Recipe</a>
      </div>
      
      <div *ngIf="recipes.length > 0" class="recipes-grid">
        <div *ngFor="let recipe of recipes" class="recipe-card card">
          <div class="recipe-header">
            <h2 class="recipe-title">{{recipe.name}}</h2>
            <div class="recipe-calories">
              {{recipe.totalNutrition.caloriesPerServing | number:'1.0-0'}} cal/serving
            </div>
          </div>
          
          <p *ngIf="recipe.description" class="recipe-description">{{recipe.description}}</p>
          
          <div class="recipe-info">
            <div class="info-item">
              <span class="info-label">Servings:</span>
              <span class="info-value">{{recipe.servings}}</span>
            </div>
            
            <div class="info-item" *ngIf="recipe.cookingTime">
              <span class="info-label">Time:</span>
              <span class="info-value">{{recipe.cookingTime}} min</span>
            </div>
            
            <div class="info-item">
              <span class="info-label">Ingredients:</span>
              <span class="info-value">{{recipe.ingredients.length}}</span>
            </div>
          </div>
          
          <div class="macros-summary">
            <div class="macro-pill">
              <span class="macro-label">P</span>
              <span class="macro-value">{{recipe.totalNutrition.protein | number:'1.0-0'}}g</span>
            </div>
            
            <div class="macro-pill">
              <span class="macro-label">F</span>
              <span class="macro-value">{{recipe.totalNutrition.fat | number:'1.0-0'}}g</span>
            </div>
            
            <div class="macro-pill">
              <span class="macro-label">C</span>
              <span class="macro-value">{{recipe.totalNutrition.carbohydrates | number:'1.0-0'}}g</span>
            </div>
          </div>
          
          <div class="recipe-actions">
            <a [routerLink]="['/nutrition-results', recipe.id]" class="btn btn-primary">View Details</a>
            <button class="btn btn-secondary" (click)="deleteRecipe(recipe.id)">Delete</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .saved-recipes {
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
    }
    
    .empty-state {
      text-align: center;
      padding: 64px 32px;
    }
    
    .empty-icon {
      font-size: 4rem;
      margin-bottom: 16px;
    }
    
    .empty-state h2 {
      margin-bottom: 8px;
    }
    
    .empty-state p {
      margin-bottom: 24px;
      color: var(--text-secondary);
    }
    
    .recipes-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 24px;
    }
    
    .recipe-card {
      display: flex;
      flex-direction: column;
      height: 100%;
    }
    
    .recipe-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 8px;
    }
    
    .recipe-title {
      margin-bottom: 0;
      font-size: 1.5rem;
    }
    
    .recipe-calories {
      background-color: var(--primary-light);
      color: var(--text-primary);
      padding: 4px 8px;
      border-radius: 16px;
      font-size: 0.875rem;
      font-weight: 500;
      white-space: nowrap;
    }
    
    .recipe-description {
      color: var(--text-secondary);
      margin-bottom: 16px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .recipe-info {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
    }
    
    .info-item {
      font-size: 0.875rem;
    }
    
    .info-label {
      color: var(--text-secondary);
      margin-right: 4px;
    }
    
    .info-value {
      font-weight: 500;
    }
    
    .macros-summary {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }
    
    .macro-pill {
      display: flex;
      align-items: center;
      background-color: var(--surface);
      padding: 4px 8px;
      border-radius: 16px;
      font-size: 0.875rem;
    }
    
    .macro-label {
      font-weight: 600;
      color: var(--text-secondary);
      margin-right: 4px;
    }
    
    .macro-value {
      font-weight: 500;
    }
    
    .recipe-actions {
      display: flex;
      gap: 8px;
      margin-top: auto;
      padding-top: 16px;
    }
    
    .recipe-actions .btn {
      flex: 1;
      text-align: center;
    }
    
    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        gap: 16px;
        align-items: flex-start;
      }
      
      .recipes-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class SavedRecipesComponent implements OnInit {
  recipes: Recipe[] = [];
  
  constructor(private recipeService: RecipeService) {}
  
  ngOnInit(): void {
    this.loadRecipes();
  }
  
  loadRecipes(): void {
    this.recipeService.getAllRecipes().subscribe(recipes => {
      this.recipes = recipes;
    });
  }
  
  deleteRecipe(id?: string): void {
    if (!id) return;
    
    if (confirm('Are you sure you want to delete this recipe?')) {
      this.recipeService.deleteRecipe(id).subscribe(success => {
        if (success) {
          this.loadRecipes();
        }
      });
    }
  }
}