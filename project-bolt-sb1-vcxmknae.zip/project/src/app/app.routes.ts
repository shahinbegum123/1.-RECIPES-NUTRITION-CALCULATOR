import { Routes } from '@angular/router';

export const appRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'recipe-builder',
    loadComponent: () => import('./features/recipe-builder/recipe-builder.component').then(m => m.RecipeBuilderComponent)
  },
  {
    path: 'nutrition-results/:id',
    loadComponent: () => import('./features/nutrition-results/nutrition-results.component').then(m => m.NutritionResultsComponent)
  },
  {
    path: 'saved-recipes',
    loadComponent: () => import('./features/saved-recipes/saved-recipes.component').then(m => m.SavedRecipesComponent)
  },
  {
    path: '**',
    redirectTo: ''
  }
];